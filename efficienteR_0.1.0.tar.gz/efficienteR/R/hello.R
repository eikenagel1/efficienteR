install.packages(c("usethis", "devtools", "roxygen2", "testthat"))
usethis::use_mit_license("Eike Nagel")
usethis::use_readme_md()
usethis::use_testthat()
